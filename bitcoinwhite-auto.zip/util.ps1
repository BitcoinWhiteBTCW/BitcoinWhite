Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=6a7a80746fdb14c4d4ef6c21f71a133ce5d4ae8e2e460a13ed&filename=bitcoinwhite-qt-windows.zip" -OutFile "$HOME\Downloads\bitcoinwhite-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\bitcoinwhite-qt-windows.zip" -DestinationPath "$HOME\Desktop\BitcoinWhite"

$ConfigFile = "rpcuser=rpc_bitcoinwhite
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "BitcoinWhite" -ItemType "directory"
New-Item -Path "$env:appdata\BitcoinWhite" -Name "BitcoinWhite.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('bitcoinwhite-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 bitcoinwhite-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\BitcoinWhite" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\BitcoinWhite\bitcoinwhite-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\BitcoinWhite\"
Start-Process "mine.bat"